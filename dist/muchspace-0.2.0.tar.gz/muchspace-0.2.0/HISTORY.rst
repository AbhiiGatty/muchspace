=======
History
=======

0.1.3 (09-06-2018)
------------------

* First release on PyPI.