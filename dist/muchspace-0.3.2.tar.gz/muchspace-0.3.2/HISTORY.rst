=======
History
=======

0.1.3 (09-06-2018)
------------------

* First release on PyPI.

0.2.0 (10-06-2018)
------------------

* First Working release.

0.3.1 (12-06-2018)
------------------

* First stable release with feature support.